________________[ QUADNET ]________________

Quadnet is freeware!
But if you like the game, please send us
email! 

martin@brainchilddesign.com

That way we'll know if anyone is playing
our games and will inspire us to continue
creating computer games.

You can ofcourse also send snailmail:
Martin Magnusson
Bj�rnk�rrsgatan 5A:32
584 36 Link�ping

__________[ Online highscores: ]___________

This is a new version of Quadnet that
supports an online highscorelist. The list
contains the worlds best Quadnet scores.
Your highscores are saved in a file called
Hiscore.txt. Open this file and copy the
row where your best score is. Visit our
community at www.brainchilddesign.com and
go to the Quadnet page in the games
section. There you will find the list and a
form where you can paste the row that you
copied. Click submit and you're done!

If you want to submit a highscore that you
got with the previous version of Quadnet,
copy the old quadnet.dat overwriting the
one in this version. Start the game and go
to the hiscore screen. Press F1 to save the
scores into Hiscore.txt.

_______________[ Bug fix: ]________________

In the original version there was a bug which
sometimes caused the game to crash when you
reached more than 1 000 000 points.
When I created the game, I didn't think it was
possible to score this high, but the more you
play, the better you get.

_____________[ Instructions: ]_____________

The default controls are:
arrowkeys to move and w, a, s, d to shoot.
These keys can be reconfigured in the menu.
Shoot the metal spheres moving around the grid
to score points. If you score high enough, you
will be granted a place in the hiscoretable.

_____________[ The creators: ]_____________

Martin Magnusson:
  id�a, programming, graphics
Anders Nilsson:
  music
Mattias Brynervall:
  sound programming

___________[ Brainchild Design ]___________

Visit our webpage to download our games:

www.brainchilddesign.com

Brainchild members:
Andreas Brynervall (andreas@brainchilddesign.com)
Mattias Brynervall (mattias@brainchilddesign.com)
Martin Magnusson (martin@brainchilddesign.com)
Anders Nilsson (anders@brainchilddesign.com)

___________[ Previous releases ]___________

Find all our previous releases at our webpage:
www.brainchilddesign.com

_________[ Technical information ]_________

Programming in C++
Compiled with the FREE 32-bit protected
mode C++ compiler DJGPP
Music in FastTracker 2
Graphics in Deluxe Paint 2
and Paint Shop Pro 5

__________[ Magazines and CD's ]___________

It's free to publish this game in a computer
magazine or in a CD collection.
Please send us an email if you do.

______[ Don't forget to send email! ]______