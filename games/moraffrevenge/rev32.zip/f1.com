"Strength:    ### "
"`Cure' heals one point of damage per       point of wizdom."
"When it works, `Gas' makes 1'st through    3'rd level creatures fall asleep,       allowing you to kill them."
CURE
GAS
"`Sense Level' determines which level you   are on."
"`Magic Zot' does about 1 to 4 points of    damage per level of the caster to all   creatures."
SENSE LEVEL
MAGIC ZOT
"Intelligence:### "
"`Strength' increases strength. It lasts    until you return to the 0'th level."
"`Magic Bolt' does about 20 or 30 point     of damage to all creatures."
STRENGTH
MAGIC BOLT
"`Speed' increases agility. It lasts        until you return to the 0'th level."
"This `Speed' spell increases agility for   a short time."
SPEED
SPEED
"Wisdom:      ### "
"`Sense Location' indicates your x,y        and level position in the dungeon."
"`Lighning Bolt' does 6 or 7 point of       damage per level of caster."
SENSE LOCATION
LIGHTNING
"`Descend' lowers you to the next level."
"This `Strength' increases strength for     a short time."
DESCEND
STRENGTH
"Health:      ### "
"`Feather' reduces player weight."
"`Go Away' sends the monster away,          leaving treasure with you. Won't        always work."
FEATHER
GO AWAY!
"`Ascend' causes you to float up one        level."
"`Rise' causes you to float up to the       next level, leaving the monster         behind."
ASCEND
RISE...
"Agility:     ### "
"`Change Level' sends you to a random       chosen level."
"`Auto kill' makes monsters fall over       dead. Does not always work."
CHANGE LEVEL
AUTO KILL
"`Invisibility' makes it difficult for      monsters to see you, making it easier   to run away from them."
"`Explosion' does lots of damage to         monsters if the caster is high level."
INVISIBILITY
EXPLOSION
"Laziness:    ### "
"`Heal' restores full health points."
"`Heal' restores full health points."
HEAL
HEAL
"`Mocciolo' is a last resort. It may kill   or save you."
"`God?' is a last resort. It may kill or     save you."
MOCCIOLO
GOD?
