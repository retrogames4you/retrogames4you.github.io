0,0
9,9
15,15
19,19
22,22
24,24
213,57
267,95
213,137
159,95
213,57
267,95
213,137
0,0,0,0,0,0,0,0
9,9,3,6,16.25,18.25,3,6
15,15,11,13,19.75,21.35,11,13
19,19,16.33333,16.66667,22.08333,23.41667,16.33333,17.66667
22,22,20,20,23.75,25.08333,20,21
"TELEPORT SCROLLS:"
"SEEING SCROLLS:"
"HEALING SCROLLS:"
"SPELL POINT SCROLLS:"
"POTIONS OF SPEED:"
"POTIONS OF FIRE:"
"POTIONS OF SHIELDING:"
"POTIONS OF HEALTH POINTS:"
"POTIONS OF RELOCATION"
" A TELEPORT SCROLL"
" A SCROLL OF SEEING"
" A SCROLL OF HEALING"
" A SPELL POINT SCROLL"
" A POTION OF SPEED"
" A POTION OF FIRE"
" A POTION OF SHIELDING"
" A POTION OF HEALTH POINTS"
" A POTION OF RELOCATION"
"Teleport Scroll: Teleports caster to       0'th level."
"Scroll of Seeing: Maps an entire level     of the dungeon."
"Scroll of Healing: Increases health        points."
"Spell Point Scroll: Increases spell        points."
"Bag of Holding: Holds about 1000 pounds    of treasure and weighs nothing."
"Floor Slosher: Lowers user to the next     deeper level."
"Level Shifter: Moves user to a new         level."
"Potion of Speed: Increases agility for     a short time,"
"Potion of Fire: Allows you to breath       fire on monsters."
"Potion of Invincibility: Makes your        armor very strong."
"Potion of Health Points: Heals wounds."
"Potion of Relocation: Moves caster to a    random location on the same level."
"Holy Hand Grenade: Blows up the            monster."
"HA HA, YOU MISSED!"
"YOU MISSED"
"GET A REAL WEAPON"
"LEARN HOW TO FIGHT!"
"YOU MISSED, YOU FOOL!"
"NICE SWING!"
"I WANT YOU FOR U.S. ARMY!"
"RIGHT IN THE -----!"
"BULLSEYE!"
"SMACK!"
"YOU FEEL COLD"
"D R A I N ..."
"YOU FEEL WEAK"
"UH OH..."
"OH SHIT!"
